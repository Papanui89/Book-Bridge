import React, { useState } from "react";
import { Review } from "@/api/entities/Review";
import { motion } from "framer-motion";
import { X, Star, Book, Send, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const THEME_OPTIONS = [
  "American Dream", "Justice", "Coming of Age", "Love", "War", 
  "Identity", "Family", "Friendship", "Power", "Freedom"
];

export default function ReviewForm({ user, onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    book_title: "",
    author: "",
    comprehensibility: 0,
    emotional_appeal: 0,
    writing_style: 0,
    pacing: 0,
    ending: 0,
    character_development: 0,
    representation: 0,
    review_text: "",
    themes: [],
    custom_themes: [],
    is_school_assigned: false,
    is_ap_book: false,
  });
  const [customTheme, setCustomTheme] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRatingChange = (category, rating) => {
    setFormData(prev => ({ ...prev, [category]: rating }));
  };

  const toggleTheme = (theme) => {
    setFormData(prev => ({
      ...prev,
      themes: prev.themes.includes(theme)
        ? prev.themes.filter(t => t !== theme)
        : [...prev.themes, theme]
    }));
  };

  const addCustomTheme = () => {
    if (customTheme.trim() && !formData.custom_themes.includes(customTheme.trim())) {
      setFormData(prev => ({
        ...prev,
        custom_themes: [...prev.custom_themes, customTheme.trim()]
      }));
      setCustomTheme("");
    }
  };

  const removeCustomTheme = (theme) => {
    setFormData(prev => ({
      ...prev,
      custom_themes: prev.custom_themes.filter(t => t !== theme)
    }));
  };

  const calculateOverallRating = () => {
    const ratings = [
      formData.comprehensibility,
      formData.emotional_appeal,
      formData.writing_style,
      formData.pacing,
      formData.ending,
      formData.character_development,
      formData.representation
    ];
    const validRatings = ratings.filter(r => r > 0);
    return validRatings.length === 7 ? (validRatings.reduce((a, b) => a + b, 0) / 7).toFixed(1) : 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    
    // Validate required fields
    if (!formData.book_title.trim()) {
      setError("Book title is required");
      return;
    }
    if (!formData.author.trim()) {
      setError("Author is required");
      return;
    }
    if (!formData.review_text.trim()) {
      setError("Review text is required");
      return;
    }
    
    // Validate all 7 categories are rated
    const requiredRatings = [
      formData.comprehensibility, formData.emotional_appeal, formData.writing_style,
      formData.pacing, formData.ending, formData.character_development, formData.representation
    ];
    if (requiredRatings.some(rating => rating === 0)) {
      setError("Please rate all 7 categories");
      return;
    }

    setLoading(true);
    
    try {
      const overallRating = calculateOverallRating();
      const reviewData = {
        book_title: formData.book_title.trim(),
        author: formData.author.trim(),
        comprehensibility: formData.comprehensibility,
        emotional_appeal: formData.emotional_appeal,
        writing_style: formData.writing_style,
        pacing: formData.pacing,
        ending: formData.ending,
        character_development: formData.character_development,
        representation: formData.representation,
        overall_rating: parseFloat(overallRating),
        rating: parseFloat(overallRating), // Add this for compatibility
        review_text: formData.review_text.trim(),
        themes: [...formData.themes, ...formData.custom_themes],
        custom_themes: formData.custom_themes,
        is_school_assigned: formData.is_school_assigned,
        is_ap_book: formData.is_ap_book,
        school: user.school,
        creator_id: user.id,
        creator_name: user.full_name,
        upvotes: 0
      };
      
      console.log("Submitting review:", reviewData);
      await Review.create(reviewData);
      onSubmit();
    } catch (error) {
      console.error("Error creating review:", error);
      setError("Failed to submit review. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  
  const renderSimpleRatingScale = (category, label, value) => {
    return (
      <div className="space-y-2">
        <Label className="text-sm font-medium text-slate-700">{label}</Label>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((rating) => (
            <button
              key={rating}
              type="button"
              onClick={() => handleRatingChange(category, rating)}
              className={`w-10 h-10 rounded-lg text-sm font-medium transition-all ${
                value >= rating
                  ? "bg-blue-600 text-white shadow-md"
                  : "bg-slate-100 text-slate-600 hover:bg-blue-100"
              }`}
            >
              {rating}
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-500">Rating: {value > 0 ? `${value}/10` : 'Not rated'}</p>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto"
      >
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="flex flex-row items-center justify-between border-b border-slate-200">
            <CardTitle className="flex items-center gap-2 font-serif text-2xl text-slate-800">
                <Book className="h-6 w-6 text-blue-600" />
                Write a Review
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onCancel}>
              <X className="h-5 w-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6">
            {/* Spoiler Warning */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h3 className="text-lg font-bold text-red-800">🚨 NO SPOILERS RULE</h3>
              </div>
              <p className="text-red-700">
                Your review must be completely spoiler-free to preserve the reading experience for others. 
                Focus on writing style, themes, characters, and your personal connection to the book without revealing plot details.
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info */}
              <div className="grid md:grid-cols-2 gap-4">
                <Input 
                  name="book_title" 
                  placeholder="Book Title *" 
                  value={formData.book_title} 
                  onChange={handleInputChange} 
                  required 
                />
                <Input 
                  name="author" 
                  placeholder="Author *" 
                  value={formData.author} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>

              {/* 7-Category Rating System */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-slate-800">Rate each category from 1-10:</h3>
                <div className="space-y-6">
                  {renderSimpleRatingScale("comprehensibility", "Comprehensibility", formData.comprehensibility)}
                  {renderSimpleRatingScale("emotional_appeal", "Emotional Appeal", formData.emotional_appeal)}
                  {renderSimpleRatingScale("writing_style", "Writing Style", formData.writing_style)}
                  {renderSimpleRatingScale("pacing", "Pacing", formData.pacing)}
                  {renderSimpleRatingScale("ending", "Ending", formData.ending)}
                  {renderSimpleRatingScale("character_development", "Character Development", formData.character_development)}
                  {renderSimpleRatingScale("representation", "Representation", formData.representation)}
                </div>
                
                {calculateOverallRating() > 0 && (
                  <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-xl font-bold text-blue-800">
                      Overall Rating: {calculateOverallRating()}/10
                    </p>
                  </div>
                )}
              </div>

              {/* Review Text */}
              <div className="space-y-2">
                <Label>Your Review *</Label>
                <Textarea 
                  name="review_text" 
                  placeholder="Share your thoughts on the book (remember: NO SPOILERS)..." 
                  value={formData.review_text} 
                  onChange={handleInputChange} 
                  required 
                  rows={6} 
                />
              </div>

              {/* Themes */}
              <div className="space-y-3">
                <Label>Select Themes</Label>
                <div className="flex flex-wrap gap-2">
                  {THEME_OPTIONS.map(theme => (
                    <Badge 
                      key={theme} 
                      onClick={() => toggleTheme(theme)} 
                      variant={formData.themes.includes(theme) ? "default" : "outline"} 
                      className="cursor-pointer transition-colors hover:bg-blue-100"
                    >
                      {theme}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Custom Themes */}
              <div className="space-y-3">
                <Label>Add Custom Themes</Label>
                <div className="flex gap-2">
                  <Input 
                    value={customTheme}
                    onChange={(e) => setCustomTheme(e.target.value)}
                    placeholder="Enter custom theme..."
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomTheme())}
                  />
                  <Button type="button" onClick={addCustomTheme} variant="outline">
                    Add
                  </Button>
                </div>
                {formData.custom_themes.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {formData.custom_themes.map(theme => (
                      <Badge 
                        key={theme} 
                        variant="secondary"
                        className="cursor-pointer hover:bg-red-100"
                        onClick={() => removeCustomTheme(theme)}
                      >
                        {theme} ×
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Book Type */}
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-slate-100 rounded-lg">
                  <Label htmlFor="is_school_assigned">Was this a school assignment?</Label>
                  <Switch 
                    id="is_school_assigned" 
                    checked={formData.is_school_assigned} 
                    onCheckedChange={(checked) => setFormData(p => ({...p, is_school_assigned: checked}))} 
                  />
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-100 rounded-lg">
                  <Label htmlFor="is_ap_book">Is this an AP Literature book?</Label>
                  <Switch 
                    id="is_ap_book" 
                    checked={formData.is_ap_book} 
                    onCheckedChange={(checked) => setFormData(p => ({...p, is_ap_book: checked}))} 
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="ghost" onClick={onCancel}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={loading || !formData.book_title || !formData.author || !formData.review_text || calculateOverallRating() == 0}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {loading ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Submit Review
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}