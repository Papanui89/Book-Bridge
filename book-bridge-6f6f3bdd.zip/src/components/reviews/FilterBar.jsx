import React from "react";
import { Filter, Star, Tag, SortAsc, BookOpen, GraduationCap } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";

const THEME_OPTIONS = [
  "American Dream", "Justice", "Coming of Age", "Love", "War", 
  "Identity", "Family", "Friendship", "Power", "Freedom", "Other"
];

export default function FilterBar({ filters, onFiltersChange }) {
  const updateFilter = (key, value) => {
    onFiltersChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="p-4 mb-8 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2 text-slate-700">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Filters:</span>
        </div>

        <div className="flex items-center gap-2">
          <Tag className="h-4 w-4 text-slate-500" />
          <Select value={filters.theme} onValueChange={(value) => updateFilter("theme", value)}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Themes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Themes</SelectItem>
              {THEME_OPTIONS.map((theme) => (
                <SelectItem key={theme} value={theme}>
                  {theme}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Star className="h-4 w-4 text-slate-500" />
          <Select value={filters.rating} onValueChange={(value) => updateFilter("rating", value)}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="All Ratings" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Ratings</SelectItem>
              <SelectItem value="9">9+ Rating</SelectItem>
              <SelectItem value="8">8+ Rating</SelectItem>
              <SelectItem value="7">7+ Rating</SelectItem>
              <SelectItem value="6">6+ Rating</SelectItem>
              <SelectItem value="5">5+ Rating</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-slate-500" />
          <Select value={filters.book_type} onValueChange={(value) => updateFilter("book_type", value)}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Books" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Books</SelectItem>
              <SelectItem value="choice">Free Choice</SelectItem>
              <SelectItem value="assigned">School Assigned</SelectItem>
              <SelectItem value="ap">AP Literature</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <SortAsc className="h-4 w-4 text-slate-500" />
          <Select value={filters.sortBy} onValueChange={(value) => updateFilter("sortBy", value)}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="highest-rated">Highest Rated</SelectItem>
              <SelectItem value="most-liked">Most Liked</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
}