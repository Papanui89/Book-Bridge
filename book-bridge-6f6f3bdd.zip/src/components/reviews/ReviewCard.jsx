
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Star, School, ThumbsUp, BookOpen, User, Trash2, MoreVertical, Heart } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Review } from "@/api/entities/Review";
import { User as UserEntity } from "@/api/entities";

export default function ReviewCard({ review, onReviewDeleted, onReviewUpdated }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [upvoting, setUpvoting] = useState(false);
  const [localReview, setLocalReview] = useState(review);

  React.useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await UserEntity.me();
      setCurrentUser(user);
    } catch (error) {
      // User not logged in
    }
  };

  const handleUpvote = async () => {
    if (!currentUser || upvoting) return;

    setUpvoting(true);
    try {
      const hasUpvoted = localReview.upvoted_by?.includes(currentUser.id) || false;
      const newUpvotedBy = hasUpvoted 
        ? (localReview.upvoted_by || []).filter(id => id !== currentUser.id)
        : [...(localReview.upvoted_by || []), currentUser.id];

      const updatedReview = {
        ...localReview,
        upvotes: newUpvotedBy.length,
        upvoted_by: newUpvotedBy
      };

      await Review.update(localReview.id, {
        upvotes: updatedReview.upvotes,
        upvoted_by: updatedReview.upvoted_by
      });

      setLocalReview(updatedReview);
      if (onReviewUpdated) {
        onReviewUpdated(updatedReview);
      }
    } catch (error) {
      console.error("Error updating upvote:", error);
    } finally {
      setUpvoting(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await Review.delete(localReview.id);
      setShowDeleteDialog(false);
      if (onReviewDeleted) {
        onReviewDeleted(localReview.id);
      }
    } catch (error) {
      console.error("Error deleting review:", error);
    } finally {
      setDeleting(false);
    }
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.round(rating / 2) // Convert 10-scale to 5-scale for display
            ? "text-amber-400 fill-current"
            : "text-slate-300"
        }`}
      />
    ));
  };

  const truncateText = (text, maxLength = 150) => {
    if (!text) return "";
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  const isOwnReview = currentUser && localReview.creator_id === currentUser.id;
  const hasUserUpvoted = currentUser && localReview.upvoted_by?.includes(currentUser.id);

  return (
    <>
      <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-0 shadow-lg h-full flex flex-col">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <h3 className="font-serif text-xl font-bold text-slate-800 mb-1 group-hover:text-blue-600 transition-colors">
                  <Link to={createPageUrl(`Review?id=${localReview.id}`)}>
                    {localReview.book_title}
                  </Link>
                </h3>
                {isOwnReview && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem 
                        onClick={() => setShowDeleteDialog(true)}
                        className="text-red-600 focus:text-red-700 focus:bg-red-50"
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Review
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
              <p className="text-sm text-slate-600 mb-2">by {localReview.author}</p>
              <div className="flex items-center gap-2 mb-3">
                {renderStars(localReview.overall_rating || localReview.rating)}
                <span className="text-sm text-slate-600">
                  {(localReview.overall_rating || localReview.rating).toFixed(1)}/10
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
            <User className="h-4 w-4" />
            <Link to={createPageUrl(`Profile?id=${localReview.creator_id}`)} className="hover:underline hover:text-blue-600 transition-colors">
              <span>{localReview.creator_name}</span>
            </Link>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
            <School className="h-4 w-4" />
            <span>{localReview.school}</span>
          </div>

          {localReview.themes && localReview.themes.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {localReview.themes.slice(0, 3).map((theme, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="text-xs bg-blue-100 text-blue-700 hover:bg-blue-200"
                >
                  {theme}
                </Badge>
              ))}
              {localReview.themes.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{localReview.themes.length - 3} more
                </Badge>
              )}
            </div>
          )}

          <div className="flex flex-wrap gap-1 mb-3">
            {localReview.is_school_assigned && (
              <Badge variant="outline" className="text-xs">
                School Assigned
              </Badge>
            )}
            {localReview.is_ap_book && (
              <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700">
                AP Literature
              </Badge>
            )}
            {!localReview.is_school_assigned && !localReview.is_ap_book && (
              <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                Free Choice
              </Badge>
            )}
          </div>
        </CardHeader>

        <CardContent className="pt-0 flex-grow flex flex-col justify-between">
          <p className="text-slate-700 leading-relaxed mb-4">
            {truncateText(localReview.review_text)}
          </p>

          <div className="flex justify-between items-center mt-auto">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleUpvote}
                disabled={!currentUser || upvoting}
                className={`flex items-center gap-1 transition-colors ${
                  hasUserUpvoted 
                    ? "text-red-600 hover:text-red-700" 
                    : "text-slate-500 hover:text-red-600"
                }`}
              >
                <Heart className={`h-4 w-4 ${hasUserUpvoted ? "fill-current" : ""}`} />
                <span>{localReview.upvotes || 0}</span>
              </Button>
            </div>

            <Link to={createPageUrl(`Review?id=${localReview.id}`)}>
              <Button
                variant="outline"
                size="sm"
                className="group-hover:bg-blue-50 group-hover:border-blue-200 group-hover:text-blue-700 transition-colors"
              >
                Read Full Review
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Review</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete your review of "{localReview.book_title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              {deleting ? "Deleting..." : "Delete Review"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
