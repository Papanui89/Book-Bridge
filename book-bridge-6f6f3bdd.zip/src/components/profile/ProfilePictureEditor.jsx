import React, { useState, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { X, RotateCw, ZoomIn, ZoomOut, Check, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

export default function ProfilePictureEditor({ 
  imageFile, 
  onSave, 
  onCancel, 
  uploading 
}) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);
  const canvasRef = useRef(null);
  const imgRef = useRef(null);

  React.useEffect(() => {
    if (imageFile) {
      const url = URL.createObjectURL(imageFile);
      setImageUrl(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [imageFile]);

  const createImage = (url) =>
    new Promise((resolve, reject) => {
      const image = new Image();
      image.addEventListener('load', () => resolve(image));
      image.addEventListener('error', (error) => reject(error));
      image.setAttribute('crossOrigin', 'anonymous');
      image.src = url;
    });

  const getCroppedImg = async (imageSrc, pixelCrop, rotation = 0) => {
    const image = await createImage(imageSrc);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    const maxSize = Math.max(image.width, image.height);
    const safeArea = 2 * ((maxSize / 2) * Math.sqrt(2));

    canvas.width = safeArea;
    canvas.height = safeArea;

    ctx.translate(safeArea / 2, safeArea / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.translate(-safeArea / 2, -safeArea / 2);

    ctx.drawImage(
      image,
      safeArea / 2 - image.width * 0.5,
      safeArea / 2 - image.height * 0.5
    );

    const data = ctx.getImageData(0, 0, safeArea, safeArea);

    canvas.width = pixelCrop.width;
    canvas.height = pixelCrop.height;

    ctx.putImageData(
      data,
      Math.round(0 - safeArea / 2 + image.width * 0.5 - pixelCrop.x),
      Math.round(0 - safeArea / 2 + image.height * 0.5 - pixelCrop.y)
    );

    return new Promise((resolve) => {
      canvas.toBlob(resolve, 'image/jpeg', 0.9);
    });
  };

  const handleSave = async () => {
    if (!imageUrl || !croppedAreaPixels) return;

    try {
      const croppedImage = await getCroppedImg(imageUrl, croppedAreaPixels, rotation);
      onSave(croppedImage);
    } catch (error) {
      console.error('Error cropping image:', error);
    }
  };

  const handleZoomChange = (value) => {
    setZoom(value[0]);
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  // Simple crop area calculation for demonstration
  const calculateCrop = () => {
    if (!imgRef.current) return;
    
    const img = imgRef.current;
    const rect = img.getBoundingClientRect();
    const size = Math.min(rect.width, rect.height) * 0.8;
    
    setCroppedAreaPixels({
      width: size / zoom,
      height: size / zoom,
      x: (rect.width - size / zoom) / 2,
      y: (rect.height - size / zoom) / 2,
    });
  };

  React.useEffect(() => {
    calculateCrop();
  }, [zoom, rotation, imageUrl]);

  if (!imageUrl) return null;

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-2xl"
      >
        <Card className="bg-white border-0 shadow-2xl">
          <CardHeader className="flex flex-row items-center justify-between border-b">
            <CardTitle className="font-serif text-xl">Edit Profile Picture</CardTitle>
            <Button variant="ghost" size="icon" onClick={onCancel}>
              <X className="h-5 w-5" />
            </Button>
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Image Preview */}
              <div className="relative">
                <div 
                  className="relative w-full h-80 bg-slate-100 rounded-lg overflow-hidden flex items-center justify-center"
                  style={{
                    background: `url(${imageUrl}) center/cover no-repeat`,
                    transform: `scale(${zoom}) rotate(${rotation}deg)`,
                    transition: 'transform 0.2s ease'
                  }}
                >
                  <img
                    ref={imgRef}
                    src={imageUrl}
                    alt="Profile preview"
                    className="max-w-full max-h-full object-contain opacity-0"
                    onLoad={calculateCrop}
                  />
                  
                  {/* Crop overlay */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-48 h-48 border-4 border-white rounded-full shadow-lg opacity-80" />
                  </div>
                </div>
                
                <div className="absolute top-2 right-2">
                  <Button
                    variant="secondary"
                    size="icon"
                    onClick={handleRotate}
                    className="bg-black/50 text-white hover:bg-black/70"
                  >
                    <RotateCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Controls */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <ZoomIn className="h-4 w-4" />
                    Zoom: {zoom.toFixed(1)}x
                  </Label>
                  <Slider
                    value={[zoom]}
                    onValueChange={handleZoomChange}
                    min={0.5}
                    max={3}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <div className="text-sm text-slate-600 bg-blue-50 p-3 rounded-lg">
                  <p className="font-medium mb-1">Editing Tips:</p>
                  <ul className="space-y-1">
                    <li>• Use the zoom slider to fit your face in the circle</li>
                    <li>• Click the rotate button to adjust orientation</li>
                    <li>• The circular area will be your final profile picture</li>
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={onCancel} disabled={uploading}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                  disabled={uploading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {uploading ? (
                    <>
                      <Upload className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Save Profile Picture
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}