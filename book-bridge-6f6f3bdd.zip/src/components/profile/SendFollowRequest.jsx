import React, { useState } from "react";
import { FollowRequest } from "@/api/entities/FollowRequest";
import { Follow } from "@/api/entities/Follow";
import { User } from "@/api/entities";
import { motion } from "framer-motion";
import { UserPlus, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function SendFollowRequest({ targetUser, onClose, onRequestSent }) {
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading current user:", error);
    }
  };

  const handleSendRequest = async () => {
    if (!currentUser || sending) return;

    setSending(true);
    try {
      // Check if already following
      const existingFollow = await Follow.filter({
        follower_id: currentUser.id,
        following_id: targetUser.id
      });

      if (existingFollow.length > 0) {
        alert("You are already following this user!");
        onClose();
        return;
      }

      // Check if request already exists
      const existingRequest = await FollowRequest.filter({
        requester_id: currentUser.id,
        requested_id: targetUser.id,
        status: "pending"
      });

      if (existingRequest.length > 0) {
        alert("You already have a pending follow request to this user!");
        onClose();
        return;
      }

      // Create follow request
      await FollowRequest.create({
        requester_id: currentUser.id,
        requester_name: currentUser.full_name,
        requester_school: currentUser.school,
        requested_id: targetUser.id,
        requested_name: targetUser.full_name,
        requested_school: targetUser.school,
        status: "pending",
        message: message.trim()
      });

      onRequestSent();
    } catch (error) {
      console.error("Error sending follow request:", error);
      alert("Failed to send follow request. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md"
      >
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="flex flex-row items-center justify-between border-b">
            <CardTitle className="flex items-center gap-2 text-lg">
              <UserPlus className="h-5 w-5 text-blue-600" />
              Send Follow Request
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>

          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-slate-700">
                  Send a follow request to <span className="font-semibold">{targetUser.full_name}</span> 
                  from <span className="text-slate-600">{targetUser.school}</span>
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Optional Message</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Hi! I'd love to connect and see your book reviews..."
                  rows={3}
                  maxLength={200}
                />
                <p className="text-xs text-slate-500 text-right">
                  {200 - message.length} characters remaining
                </p>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSendRequest}
                  disabled={sending}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {sending ? (
                    "Sending..."
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send Request
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}