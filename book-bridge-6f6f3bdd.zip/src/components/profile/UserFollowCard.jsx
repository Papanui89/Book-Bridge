
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Follow } from "@/api/entities/Follow";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import SendFollowRequest from "./SendFollowRequest";

export default function UserFollowCard({ user: targetUser, currentUser, isFollowing, onFollowChange }) {
  // isFollowing is now a prop, so we don't manage it as internal state here.
  const [isMutualFollow, setIsMutualFollow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showFollowRequest, setShowFollowRequest] = useState(false);

  useEffect(() => {
    checkFollowStatus();
  }, [targetUser, currentUser, isFollowing]); // isFollowing is a dependency as mutual status depends on it

  const checkFollowStatus = async () => {
    if (!currentUser || !targetUser) return;
    try {
      // We only need to check if the targetUser is following currentUser for mutual status
      const followedBy = await Follow.filter({
        follower_id: targetUser.id,
        following_id: currentUser.id
      });
      
      // isFollowing status comes from props
      setIsMutualFollow(isFollowing && followedBy.length > 0);
    } catch (error) {
      console.error("Error checking follow status:", error);
    }
  };
  
  // This function replaces the "unfollow" part of the old handleFollowToggle
  const handleUnfollow = async () => {
    if (!currentUser || !targetUser) return;
    
    setLoading(true);
    try {
      const records = await Follow.filter({ 
        follower_id: currentUser.id, 
        following_id: targetUser.id 
      });
      if (records.length > 0) {
        await Follow.delete(records[0].id);
      }
      if (onFollowChange) onFollowChange(false); // Notify parent that unfollow occurred
    } catch (error) {
      console.error("Error unfollowing:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendFollowRequest = () => {
    setShowFollowRequest(true);
  };

  const handleRequestSent = () => {
    setShowFollowRequest(false);
    // Optionally, you could trigger a parent update or show a success message here
  };

  const isOwnCard = currentUser?.id === targetUser.id;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="h-full"
      >
        <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-0 shadow-lg h-full flex flex-col">
          {/* Card content adapted for a vertical user card layout */}
          <div className="flex flex-col items-center p-4">
            <Avatar className="w-16 h-16 mb-3">
              <AvatarImage src={targetUser.profile_picture || `https://api.dicebear.com/6.x/identicon/svg?seed=${targetUser.full_name}`} />
              <AvatarFallback className="text-xl">{targetUser.full_name?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <div className="text-center">
              <p className="font-semibold text-slate-800 text-lg">{targetUser.full_name}</p>
              <p className="text-sm text-slate-500">{targetUser.school}</p>
              {isMutualFollow && (
                <p className="text-xs text-blue-600 font-medium mt-1">Mutual Follow</p>
              )}
            </div>
          </div>
          
          {/* Button section - moved to the bottom of the card using mt-auto */}
          {!isOwnCard && currentUser && (
            <div className="mt-auto p-4 pt-0">
              {isFollowing ? (
                <Button
                  onClick={handleUnfollow}
                  disabled={loading}
                  variant="outline"
                  className="w-full border-red-300 text-red-600 hover:bg-red-50"
                >
                  {loading ? "Unfollowing..." : "Unfollow"}
                </Button>
              ) : (
                <Button
                  onClick={handleSendFollowRequest}
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <UserPlus className="mr-2 h-4 w-4" />
                  Send Follow Request
                </Button>
              )}
            </div>
          )}
        </Card>
      </motion.div>

      {/* Follow Request Modal */}
      {showFollowRequest && (
        <SendFollowRequest
          targetUser={targetUser}
          onClose={() => setShowFollowRequest(false)}
          onRequestSent={handleRequestSent}
        />
      )}
    </>
  );
}
