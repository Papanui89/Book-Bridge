import React, { useState } from "react";
import { FollowRequest } from "@/api/entities/FollowRequest";
import { Follow } from "@/api/entities/Follow";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { UserPlus, Check, X, School, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function FollowRequestCard({ request, onRequestHandled }) {
  const [processing, setProcessing] = useState(false);

  const handleAccept = async () => {
    setProcessing(true);
    try {
      // Create follow relationship
      await Follow.create({
        follower_id: request.requester_id,
        follower_name: request.requester_name,
        follower_school: request.requester_school,
        following_id: request.requested_id,
        following_name: request.requested_name,
        following_school: request.requested_school
      });

      // Update request status
      await FollowRequest.update(request.id, { status: "accepted" });
      
      onRequestHandled(request.id);
    } catch (error) {
      console.error("Error accepting follow request:", error);
    } finally {
      setProcessing(false);
    }
  };

  const handleDecline = async () => {
    setProcessing(true);
    try {
      await FollowRequest.update(request.id, { status: "declined" });
      onRequestHandled(request.id);
    } catch (error) {
      console.error("Error declining follow request:", error);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
        <CardHeader className="pb-3">
          <div className="flex items-start gap-3">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="bg-blue-100 text-blue-600 font-semibold">
                {request.requester_name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <UserPlus className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-600">Follow Request</span>
              </div>
              <Link 
                to={createPageUrl(`Profile?id=${request.requester_id}`)}
                className="font-semibold text-slate-800 hover:text-blue-600 transition-colors"
              >
                {request.requester_name}
              </Link>
              <div className="flex items-center gap-1 text-sm text-slate-600 mt-1">
                <School className="h-3 w-3" />
                <span>{request.requester_school}</span>
              </div>
            </div>
            <div className="text-xs text-slate-500">
              {new Date(request.created_date).toLocaleDateString()}
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          {request.message && (
            <div className="mb-4 p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="h-3 w-3 text-slate-500" />
                <span className="text-xs font-medium text-slate-600">Message:</span>
              </div>
              <p className="text-sm text-slate-700 italic">"{request.message}"</p>
            </div>
          )}

          <div className="flex gap-2">
            <Button
              onClick={handleAccept}
              disabled={processing}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              <Check className="mr-2 h-4 w-4" />
              Accept
            </Button>
            <Button
              onClick={handleDecline}
              disabled={processing}
              variant="outline"
              className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
            >
              <X className="mr-2 h-4 w-4" />
              Decline
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}