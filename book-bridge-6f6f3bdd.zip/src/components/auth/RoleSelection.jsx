import React, { useState } from "react";
import { User } from "@/api/entities";
import { BlockedEmail } from "@/api/entities/BlockedEmail";
import { motion } from "framer-motion";
import { BookOpen, GraduationCap, Users, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const GRADES = ["freshman", "sophomore", "junior", "senior"];

export default function RoleSelection({ email, onRoleSelected, onEmailBlocked }) {
  const [userType, setUserType] = useState("");
  const [school, setSchool] = useState("");
  const [grade, setGrade] = useState("");
  const [loading, setLoading] = useState(false);

  const handleUserTypeSelect = async (type) => {
    if (type === "teacher") {
      setLoading(true);
      try {
        await BlockedEmail.create({
          email: email.toLowerCase(),
          reason: "teacher_selection",
        });
        await User.updateMyUserData({ user_type: "teacher", blocked: true });
        onEmailBlocked();
      } catch (error) {
        console.error("Error blocking teacher:", error);
      } finally {
        setLoading(false);
      }
      return;
    }
    setUserType(type);
  };

  const handleFinalSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      console.log("Updating user with data:", {
        user_type: userType,
        school: school.trim(),
        grade: grade,
        bio: "",
        favorite_genres: [],
        blocked: false
      });

      await User.updateMyUserData({
        user_type: userType,
        school: school.trim(),
        grade: grade,
        bio: "",
        favorite_genres: [],
        blocked: false
      });

      console.log("User data updated successfully");
      onRoleSelected();
    } catch (error) {
      console.error("Error updating user data:", error);
      alert("Failed to save profile. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md"
      >
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="text-center border-b border-slate-200">
            <div className="flex justify-center items-center gap-2 mb-4">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <span className="font-serif text-2xl font-bold gradient-text">BookBridge</span>
            </div>
            <CardTitle className="font-serif text-xl text-slate-800">
              Welcome! Let's Get You Set Up.
            </CardTitle>
            <p className="text-slate-600 mt-2">
              Just a few more details to complete your profile.
            </p>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleFinalSubmit} className="space-y-6">
              <div className="space-y-3">
                <Label className="text-sm font-medium text-slate-700">I am a:</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => handleUserTypeSelect("student")} disabled={loading} className={`p-4 rounded-lg border-2 transition-all ${userType === "student" ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 hover:border-slate-300 text-slate-600"}`}>
                    <GraduationCap className="h-8 w-8 mx-auto mb-2" />
                    <div className="font-medium">Student</div>
                  </button>
                  <button type="button" onClick={() => handleUserTypeSelect("teacher")} disabled={loading} className="p-4 rounded-lg border-2 border-slate-200 hover:border-slate-300 text-slate-600 transition-all">
                    <Users className="h-8 w-8 mx-auto mb-2" />
                    <div className="font-medium">Teacher</div>
                  </button>
                </div>
              </div>

              {userType === "student" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="school">School *</Label>
                    <Input id="school" value={school} onChange={(e) => setSchool(e.target.value)} placeholder="Enter your school name" className="border-slate-300 focus:border-blue-500" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="grade">Grade Level *</Label>
                    <Select value={grade} onValueChange={setGrade} required>
                      <SelectTrigger><SelectValue placeholder="Select your grade" /></SelectTrigger>
                      <SelectContent>{GRADES.map((gradeLevel) => (<SelectItem key={gradeLevel} value={gradeLevel}>{gradeLevel.charAt(0).toUpperCase() + gradeLevel.slice(1)}</SelectItem>))}</SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" disabled={!school.trim() || !grade || loading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                    {loading ? "Saving..." : <>Complete Profile <Sparkles className="ml-2 h-4 w-4" /></>}
                  </Button>
                </>
              )}
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}