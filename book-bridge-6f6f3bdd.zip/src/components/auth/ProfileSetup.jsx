import React, { useState } from "react";
import { User } from "@/api/entities";
import { Profile } from "@/api/entities/Profile";
import { motion } from "framer-motion";
import { BookOpen, UserCheck, AtSign, School, GraduationCap, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const GRADES = ["freshman", "sophomore", "junior", "senior"];

export default function ProfileSetup({ user, onProfileCreated }) {
    const [formData, setFormData] = useState({
        displayName: user.full_name || "",
        handle: user.full_name?.toLowerCase().replace(/\s/g, '') || "",
        school: "",
        grade: ""
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name === 'handle') {
            setFormData(prev => ({ ...prev, [name]: value.toLowerCase().replace(/[^a-z0-9_]/g, '') }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const handleGradeChange = (value) => {
        setFormData(prev => ({...prev, grade: value}));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!formData.handle || !formData.displayName || !formData.school || !formData.grade) {
            setError("Please fill out all fields.");
            return;
        }

        setLoading(true);

        try {
            // 1. Check if handle is unique
            const existingProfiles = await Profile.filter({ handle: formData.handle });
            if (existingProfiles.length > 0) {
                setError("This handle is already taken. Please choose another one.");
                setLoading(false);
                return;
            }

            // 2. Create the Profile record
            const newProfile = await Profile.create({
                handle: formData.handle,
                display_name: formData.displayName,
                school: formData.school,
                grade: formData.grade,
                bio: "New to BookBridge! Ready to share my thoughts on great books.",
                avatar_url: `https://api.dicebear.com/6.x/initials/svg?seed=${formData.displayName}`
            });

            // 3. Update the core User record
            await User.updateMyUserData({
                profile_completed: true,
                profile_handle: newProfile.handle,
                avatar_url: newProfile.avatar_url
            });

            // 4. Signal completion
            onProfileCreated();

        } catch (err) {
            console.error("Error creating profile:", err);
            setError("An unexpected error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-md"
            >
                <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
                    <CardHeader className="text-center">
                        <div className="inline-block mx-auto p-3 bg-blue-100 rounded-full mb-4">
                           <UserCheck className="h-8 w-8 text-blue-600" />
                        </div>
                        <CardTitle className="font-serif text-2xl text-slate-800">
                            Complete Your Profile
                        </CardTitle>
                        <p className="text-slate-600 mt-2">
                            Choose a unique handle and tell us a bit about yourself.
                        </p>
                    </CardHeader>
                    <CardContent className="p-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <Label htmlFor="displayName">Display Name</Label>
                                <Input id="displayName" name="displayName" value={formData.displayName} onChange={handleInputChange} />
                            </div>
                            <div>
                                <Label htmlFor="handle">Unique Handle</Label>
                                <div className="relative">
                                    <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                    <Input id="handle" name="handle" value={formData.handle} onChange={handleInputChange} className="pl-10" />
                                </div>
                            </div>
                            <div>
                                <Label htmlFor="school">School</Label>
                                <Input id="school" name="school" value={formData.school} onChange={handleInputChange} placeholder="e.g., Harvard-Westlake School" />
                            </div>
                            <div>
                                <Label htmlFor="grade">Grade Level</Label>
                                <Select value={formData.grade} onValueChange={handleGradeChange}>
                                    <SelectTrigger><SelectValue placeholder="Select your grade" /></SelectTrigger>
                                    <SelectContent>{GRADES.map(g => <SelectItem key={g} value={g}>{g.charAt(0).toUpperCase() + g.slice(1)}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                            
                            {error && <p className="text-sm text-red-600">{error}</p>}

                            <Button type="submit" disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
                                {loading ? "Saving..." : <>Create My Profile <Sparkles className="ml-2 h-4 w-4"/></>}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
}