import React from "react";
import { motion } from "framer-motion";
import { BookOpen, X, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { User } from "@/api/entities";

export default function TeacherBlock() {
  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-lg"
      >
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="text-center border-b border-red-200 bg-red-50">
            <div className="flex justify-center items-center gap-2 mb-4">
              <BookOpen className="h-8 w-8 text-red-600" />
              <span className="font-serif text-2xl font-bold text-red-600">BookBridge</span>
            </div>
          </CardHeader>

          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <X className="h-20 w-20 text-red-500 mx-auto mb-6" />
              <h1 className="font-serif text-4xl md:text-5xl font-bold text-red-600 mb-4">
                Sorryyy, students only
              </h1>
              <p className="text-lg text-slate-600 leading-relaxed mb-4">
                BookBridge is exclusively designed for student voices. 
                Teachers and educators are not permitted to join this platform.
              </p>
            </div>

            <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-red-600" />
                <span className="text-sm font-medium text-red-800">Permanent Restriction</span>
              </div>
              <p className="text-sm text-red-800">
                Your email address has been permanently blocked from accessing BookBridge. 
                This restriction cannot be removed or bypassed.
              </p>
            </div>

            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              Sign Out
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}