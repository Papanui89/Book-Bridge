import React, { useState, useEffect } from "react";
import { Review } from "@/api/entities/Review";
import { BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

import ReviewCard from "../reviews/ReviewCard";

export default function RelatedReviews({ bookTitle, currentReviewId }) {
  const [relatedReviews, setRelatedReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRelatedReviews();
  }, [bookTitle, currentReviewId]);

  const loadRelatedReviews = async () => {
    try {
      const allReviews = await Review.list("-created_date");
      const related = allReviews.filter(review => 
        review.book_title === bookTitle && review.id !== currentReviewId
      ).slice(0, 3);
      setRelatedReviews(related);
    } catch (error) {
      console.error("Error loading related reviews:", error);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 bg-slate-200 rounded mb-4 w-64"></div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-64 bg-slate-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (relatedReviews.length === 0) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-serif text-2xl text-slate-800">
            <BookOpen className="h-6 w-6 text-blue-600" />
            More takes on "{bookTitle}"
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedReviews.map((review, index) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <ReviewCard review={review} />
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}