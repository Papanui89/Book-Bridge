import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PenSquare, Star, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RecentReviewsList({ reviews }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-serif text-xl text-slate-800">
            <PenSquare className="h-5 w-5 text-blue-600" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reviews.length > 0 ? (
              reviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-slate-800">{review.book_title}</h4>
                        <p className="text-sm text-slate-600">by {review.author}</p>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-amber-600">
                        <span>{review.rating}</span>
                        <Star className="h-4 w-4" />
                      </div>
                    </div>
                    <Link to={createPageUrl(`Review?id=${review.id}`)}>
                      <Button variant="link" size="sm" className="p-0 h-auto mt-1">
                        View Review <ArrowRight className="ml-1 h-3 w-3" />
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              ))
            ) : (
              <p className="text-slate-500 text-center py-8">No reviews written yet.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}