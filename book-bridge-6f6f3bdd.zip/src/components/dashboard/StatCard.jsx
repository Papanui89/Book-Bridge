import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StatCard({ title, value, icon, color }) {
  const colors = {
    blue: "from-blue-100",
    amber: "from-amber-100",
    green: "from-green-100",
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className={`bg-white/80 backdrop-blur-sm border-0 shadow-lg h-full`}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
          {icon}
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-slate-800">{value}</div>
        </CardContent>
      </Card>
    </motion.div>
  );
}