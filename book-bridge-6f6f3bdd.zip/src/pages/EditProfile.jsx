import React from "react";
export default function EditProfilePage() {
    return <div>Edit Profile Page - Coming Soon!</div>;
}