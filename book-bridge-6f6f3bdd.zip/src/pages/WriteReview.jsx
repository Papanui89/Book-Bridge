import React from "react";
export default function WriteReviewPage() {
    return <div>Write Review Page - Coming Soon!</div>;
}