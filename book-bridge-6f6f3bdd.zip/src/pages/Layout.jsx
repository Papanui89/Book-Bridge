
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BookOpen, Rss, Search, Plus, User as UserIcon, MessageCircle, LogOut, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities";
import ProfileSetup from "./components/auth/ProfileSetup.jsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";


export default function Layout({ children }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showProfileSetup, setShowProfileSetup] = useState(false);

  useEffect(() => {
    checkAuthAndProfile();
  }, [location.pathname]);

  const checkAuthAndProfile = async () => {
    setLoading(true);
    const isPublicProfilePage = window.location.pathname.startsWith(createPageUrl("ProfilePage").slice(0,-1));

    try {
      const currentUser = await User.me();
      setUser(currentUser);
      if (!currentUser.profile_completed) {
        setShowProfileSetup(true);
      } else {
        setShowProfileSetup(false);
      }
    } catch (error) {
      setUser(null);
      setShowProfileSetup(false);
      
      const isPublicPage = window.location.pathname === createPageUrl("Home") || isPublicProfilePage;
      
      if (!isPublicPage) {
        User.loginWithRedirect(window.location.href);
      }
    }
    
    setLoading(false);
  };
  
  const handleProfileCreated = () => {
    setShowProfileSetup(false);
    checkAuthAndProfile(); // Re-check to get the updated user state
  };
  
  const handleLogout = async () => {
    await User.logout();
    setUser(null);
    window.location.href = createPageUrl("Home");
  };
  
  const isHomePage = location.pathname === createPageUrl("Home");

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (showProfileSetup && user) {
    return <ProfileSetup user={user} onProfileCreated={handleProfileCreated} />;
  }


  return (
    <div className="min-h-screen bg-slate-50">
      {!isHomePage && (
        <header className="bg-white/95 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <Link to={createPageUrl("Home")} className="flex items-center space-x-2">
                <BookOpen className="h-7 w-7 text-blue-600" />
                <span className="font-serif text-2xl font-bold text-slate-800">BookBridge</span>
              </Link>

              {user && (
                <div className="hidden md:flex items-center space-x-6">
                  <Link to={createPageUrl("Feed")} className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors font-medium">
                    <Rss className="h-5 w-5" />
                    <span>Feed</span>
                  </Link>
                  <Link to={createPageUrl("Discover")} className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors font-medium">
                    <Search className="h-5 w-5" />
                    <span>Discover</span>
                  </Link>
                </div>
              )}

              <div className="flex items-center space-x-4">
                {user ? (
                  <>
                    <Link to={createPageUrl("WriteReview")}>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" /> New Review
                      </Button>
                    </Link>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="flex items-center gap-2 p-1 h-auto rounded-full">
                           <Avatar className="h-9 w-9">
                             <AvatarImage src={user.avatar_url} alt={user.full_name} />
                             <AvatarFallback>{user.full_name?.charAt(0)}</AvatarFallback>
                           </Avatar>
                           <ChevronDown className="h-4 w-4 text-slate-500" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        <DropdownMenuLabel>{user.full_name}</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <Link to={createPageUrl(`ProfilePage?handle=${user.profile_handle}`)}>
                          <DropdownMenuItem>
                            <UserIcon className="mr-2 h-4 w-4" />
                            <span>My Profile</span>
                          </DropdownMenuItem>
                        </Link>
                        <Link to={createPageUrl("Inbox")}>
                          <DropdownMenuItem>
                            <MessageCircle className="mr-2 h-4 w-4" />
                            <span>Inbox</span>
                          </DropdownMenuItem>
                        </Link>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={handleLogout} className="text-red-600 focus:text-red-700 focus:bg-red-50">
                          <LogOut className="mr-2 h-4 w-4" />
                          <span>Log Out</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </>
                ) : (
                   <Button onClick={() => User.loginWithRedirect(window.location.href)} className="bg-blue-600 hover:bg-blue-700 text-white">
                      Sign In
                   </Button>
                )}
              </div>
            </div>
          </div>
        </header>
      )}

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

    </div>
  );
}
