import Layout from "./Layout.jsx";

import Home from "./Home";

import Profile from "./Profile";

import ProfilePage from "./ProfilePage";

import Feed from "./Feed";

import Discover from "./Discover";

import WriteReview from "./WriteReview";

import EditProfile from "./EditProfile";

import Inbox from "./Inbox";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Profile: Profile,
    
    ProfilePage: ProfilePage,
    
    Feed: Feed,
    
    Discover: Discover,
    
    WriteReview: WriteReview,
    
    EditProfile: EditProfile,
    
    Inbox: Inbox,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/ProfilePage" element={<ProfilePage />} />
                
                <Route path="/Feed" element={<Feed />} />
                
                <Route path="/Discover" element={<Discover />} />
                
                <Route path="/WriteReview" element={<WriteReview />} />
                
                <Route path="/EditProfile" element={<EditProfile />} />
                
                <Route path="/Inbox" element={<Inbox />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}