import React, { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Profile } from "@/api/entities/Profile";
import { BookReview } from "@/api/entities/BookReview";
import { UserFollow } from "@/api/entities/UserFollow";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { UserPlus, Edit, Check } from "lucide-react";

const ProfileHeader = ({ profile, reviewsCount, isOwnProfile, isFollowing, onFollowToggle }) => {
    return (
        <Card className="mb-8 p-6 bg-white border-0 shadow-sm">
            <div className="flex items-center gap-8">
                <Avatar className="h-24 w-24 md:h-32 md:w-32 border-4 border-white shadow-md">
                    <AvatarImage src={profile.avatar_url} />
                    <AvatarFallback className="text-4xl">{profile.display_name?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                    <div className="flex items-center gap-4 mb-2">
                        <h1 className="text-2xl font-bold text-slate-800">{profile.display_name}</h1>
                        <span className="text-lg text-slate-500">@{profile.handle}</span>
                    </div>
                    <div className="flex items-center gap-6 mb-4 text-slate-600">
                        <span><span className="font-bold">{reviewsCount}</span> Reviews</span>
                        <span><span className="font-bold">{profile.followers_count}</span> Followers</span>
                        <span><span className="font-bold">{profile.following_count}</span> Following</span>
                    </div>
                    <p className="text-slate-700 mb-2">{profile.bio}</p>
                    <p className="text-sm text-slate-500">{profile.school} • {profile.grade}</p>
                    
                    <div className="mt-4">
                        {isOwnProfile ? (
                            <Link to={createPageUrl(`EditProfile`)}>
                                <Button variant="outline"><Edit className="mr-2 h-4 w-4"/>Edit Profile</Button>
                            </Link>
                        ) : (
                            <Button onClick={onFollowToggle}>
                                {isFollowing ? <><Check className="mr-2 h-4 w-4"/>Following</> : <><UserPlus className="mr-2 h-4 w-4"/>Follow</>}
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </Card>
    );
};

const ReviewGrid = ({ reviews }) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {reviews.map(review => (
                <Card key={review.id} className="overflow-hidden bg-white border-0 shadow-sm hover:shadow-lg transition-shadow">
                    <img src={review.book_cover_url || `https://placehold.co/400x600/e2e8f0/64748b?text=${review.book_title.replace(/\s/g, '+')}`} alt={review.book_title} className="w-full h-48 object-cover" />
                    <CardContent className="p-4">
                        <h3 className="font-semibold truncate">{review.book_title}</h3>
                        <p className="text-sm text-slate-600">by {review.author}</p>
                        <div className="flex items-center mt-2">
                            {Array.from({length: 5}).map((_, i) => <span key={i} className={i < review.rating ? 'text-amber-400' : 'text-slate-300'}>★</span>)}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}

export default function ProfilePage() {
    const [searchParams] = useSearchParams();
    const handle = searchParams.get("handle");

    const [profile, setProfile] = useState(null);
    const [reviews, setReviews] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [isFollowing, setIsFollowing] = useState(false);

    useEffect(() => {
        loadProfile();
    }, [handle]);
    
    const loadProfile = async () => {
        setLoading(true);
        setError(null);
        try {
            const loggedInUser = await User.me().catch(() => null);
            setCurrentUser(loggedInUser);

            const profiles = await Profile.filter({ handle });
            if (profiles.length === 0) {
                setError("Profile not found.");
                setLoading(false);
                return;
            }
            
            const targetProfile = profiles[0];
            setProfile(targetProfile);

            const bookReviews = await BookReview.filter({ user_id: targetProfile.created_by }, "-created_date");
            setReviews(bookReviews);
            
            if (loggedInUser && loggedInUser.id !== targetProfile.created_by) {
                const followCheck = await UserFollow.filter({ follower_id: loggedInUser.id, following_id: targetProfile.created_by });
                setIsFollowing(followCheck.length > 0);
            }

        } catch (err) {
            setError("Failed to load profile.");
            console.error(err);
        }
        setLoading(false);
    };

    const handleFollowToggle = async () => {
        if (!currentUser || !profile) return;
        
        const followData = {
            follower_id: currentUser.id,
            follower_handle: currentUser.profile_handle,
            following_id: profile.created_by,
            following_handle: profile.handle
        };

        if (isFollowing) {
            // Unfollow logic
            const follows = await UserFollow.filter({ follower_id: currentUser.id, following_id: profile.created_by });
            if (follows.length > 0) {
                await UserFollow.delete(follows[0].id);
                setIsFollowing(false);
                // Decrement counts
                await Profile.update(profile.id, { followers_count: (profile.followers_count || 1) - 1 });
                const myProfile = await Profile.filter({handle: currentUser.profile_handle});
                await Profile.update(myProfile[0].id, { following_count: (myProfile[0].following_count || 1) - 1 });

            }
        } else {
            // Follow logic
            await UserFollow.create(followData);
            setIsFollowing(true);
            // Increment counts
            await Profile.update(profile.id, { followers_count: (profile.followers_count || 0) + 1 });
            const myProfile = await Profile.filter({handle: currentUser.profile_handle});
            await Profile.update(myProfile[0].id, { following_count: (myProfile[0].following_count || 0) + 1 });
        }
        loadProfile(); // Refresh profile to get updated counts
    };

    if (loading) return <div className="text-center">Loading profile...</div>;
    if (error) return <div className="text-center text-red-500">{error}</div>;
    if (!profile) return <div className="text-center">This profile does not exist.</div>;

    const isOwnProfile = currentUser?.id === profile.created_by;

    return (
        <div>
            <ProfileHeader 
                profile={profile}
                reviewsCount={reviews.length}
                isOwnProfile={isOwnProfile}
                isFollowing={isFollowing}
                onFollowToggle={handleFollowToggle}
            />
            <ReviewGrid reviews={reviews} />
        </div>
    );
}