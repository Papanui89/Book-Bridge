import React from "react";
export default function DiscoverPage() {
    return <div>Discover Page - Coming Soon!</div>;
}