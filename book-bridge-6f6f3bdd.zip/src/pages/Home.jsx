
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BookOpen, Users, MessageCircle, Star, ArrowRight, Quote, Gift, Sparkles, Swords, Mic, UserPlus, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { User } from "@/api/entities";

export default function Home() {
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      setUser(null);
    }
  };

  const handleGetStarted = async () => {
    if (user) {
      window.location.href = createPageUrl("Reviews");
    } else {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Reviews"));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <style>
        {`
          .font-serif { font-family: 'Playfair Display', Georgia, serif; }
          .gradient-text {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
        `}
      </style>

      {/* Header / Navigation Bar */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-blue-600" />
            <span className="font-serif text-3xl font-bold gradient-text">
              BookBridge
            </span>
          </Link>

          <nav className="hidden md:flex space-x-8">
            <a href="#our-mission" className="text-lg font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Our Mission
            </a>
            <a href="#why-bookbridge" className="text-lg font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Why BookBridge?
            </a>
            <Link to={createPageUrl("About")} className="text-lg font-medium text-slate-700 hover:text-blue-600 transition-colors">
              About Us
            </Link>
          </nav>

          <div className="flex gap-3">
            <Button
              onClick={handleGetStarted}
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
            >
              {user ? "Go to Reviews" : "Browse Reviews"}
            </Button>
            {!user && (
              <Button
                onClick={handleGetStarted}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 text-md rounded-full"
              >
                <UserPlus className="mr-2 h-4 w-4" />
                Create Your Account
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-indigo-500/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-3 mb-8">
              <BookOpen className="h-16 w-16 text-blue-600" />
              <h1 className="font-serif text-6xl lg:text-7xl font-bold gradient-text">
                BookBridge
              </h1>
            </div>
            
            <p className="font-serif text-xl lg:text-2xl text-slate-600 mb-4 max-w-3xl mx-auto leading-relaxed">
              "For Students, By Students."
            </p>
            
            <p className="text-lg text-slate-600 mb-4 max-w-2xl mx-auto">
              Built from a Harvard pre-college program to connect student readers across schools through authentic book reviews.
            </p>
            
            <p className="text-lg text-slate-600 mb-12 max-w-2xl mx-auto font-medium">
              Discover what students are saying about the books they're reading for fun, pleasure, and the pursuit of knowledge.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={handleGetStarted}
                variant="outline"
                className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg rounded-full"
              >
                Browse Student Reviews
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section id="our-mission" className="bg-blue-100/60 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-200 rounded-full mb-6 ring-4 ring-white">
            <Award className="h-8 w-8 text-blue-700" />
          </div>
          <h2 className="font-serif text-4xl font-bold text-slate-800 mb-4">
            Our Mission: Empowering Tomorrow's Leaders
          </h2>
          <p className="text-xl text-slate-700 leading-relaxed max-w-3xl mx-auto mb-6">
            We believe education and knowledge are key for nurturing our next generation of thinkers, activists, and politically engaged citizens. Every review you write helps us raise money for youth literacy through our nonprofit initiative.
          </p>
          <p className="text-lg text-slate-600 leading-relaxed max-w-3xl mx-auto">
            Your voice doesn't just share opinions—it funds our mission to get books into the hands of students who need them most.
          </p>
        </div>
      </section>

      {/* Why BookBridge Section */}
      <section id="why-bookbridge" className="py-20 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
              The Underground Library, Reimagined.
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              This isn't your teacher's book club. It's a student-built space for honest takes about books we choose to read for fun, knowledge, and personal growth.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6 group-hover:bg-blue-200 transition-colors">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-800 mb-4">
                  For Students, By Students
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  A private, student-only space. Share honest reviews about books you're reading for pleasure and discovery—no teachers allowed.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mb-6 group-hover:bg-indigo-200 transition-colors">
                  <BookOpen className="h-8 w-8 text-indigo-600" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-800 mb-4">
                  Free Reading Focus
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  Discover books students are reading by choice. See the power of self-selected reading and join healthy discussions about literature.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-6 group-hover:bg-purple-200 transition-colors">
                  <Sparkles className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-800 mb-4">
                  AP Books & More
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  Dedicated sections for AP literature, classics, and contemporary works. Find reviews tailored to your academic and personal interests.
                </p>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-6 group-hover:bg-green-200 transition-colors">
                  <Gift className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-800 mb-4">
                  Nonprofit Mission
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  Every review supports youth literacy. Donations go directly to purchasing books for underserved communities and school libraries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-400">&copy; 2024 BookBridge. A nonprofit initiative empowering student voices through literature.</p>
          <p className="text-sm mt-2 text-slate-500">Built from a Harvard pre-college program • For Students, By Students</p>
          <p className="text-xs mt-3 text-slate-600">Engineered by Luis Cadena</p>
        </div>
      </footer>
    </div>
  );
}
