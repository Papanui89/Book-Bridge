
import React, { useState, useEffect } from "react";
import { useSearchParams, Link as RouterLink } from "react-router-dom";
import { User } from "@/api/entities";
import { Review } from "@/api/entities/Review";
import { Follow } from "@/api/entities/Follow";
import { UploadFile } from "@/api/integrations";
import { motion } from "framer-motion";
import { BookOpen, User as UserIcon, School, GraduationCap, Heart, Edit, Check, X, UserPlus, MessageCircle, Camera, Save } from "lucide-react";
import { createPageUrl } from "@/utils";

import ReviewCard from "../components/reviews/ReviewCard";
import ProfilePictureEditor from "../components/profile/ProfilePictureEditor";
import SendFollowRequest from "../components/profile/SendFollowRequest";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

const GRADES = ["freshman", "sophomore", "junior", "senior"];
const GENRES = ["Fantasy", "Sci-Fi", "Mystery", "Thriller", "Romance", "Historical Fiction", "Non-Fiction", "Dystopian"];

export default function ProfilePage() {
  const [searchParams] = useSearchParams();
  const profileId = searchParams.get("id");

  const [currentUser, setCurrentUser] = useState(null);
  const [profileUser, setProfileUser] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  
  const [editingBio, setEditingBio] = useState(false);
  const [newBio, setNewBio] = useState("");
  
  const [editingProfile, setEditingProfile] = useState(false);
  const [editForm, setEditForm] = useState({
    school: "",
    grade: "",
    favorite_genres: []
  });
  
  const [showFollowRequest, setShowFollowRequest] = useState(false);
  const [showPhotoEditor, setShowPhotoEditor] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadData();
  }, [profileId]);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    setProfileUser(null);

    console.log("Loading profile data for ID:", profileId);

    let loggedInUser = null;
    try {
        loggedInUser = await User.me();
        setCurrentUser(loggedInUser);
        console.log("Current user loaded:", loggedInUser.full_name, loggedInUser.id);
    } catch (e) {
        console.log("No user logged in");
        setCurrentUser(null);
    }

    const targetId = profileId || loggedInUser?.id;

    if (!targetId) {
        setError("No profile to display. Please log in or provide a profile ID.");
        setLoading(false);
        return;
    }

    console.log("Target user ID:", targetId);

    try {
        // Try different ways to find the user
        console.log("Attempting to fetch user with filter...");
        const users = await User.filter({ id: targetId });
        console.log("User.filter result:", users);
        
        if (users && users.length > 0) {
            const userToDisplay = users[0];
            console.log("Found user:", userToDisplay);
            setProfileUser(userToDisplay);

            setNewBio(userToDisplay.bio || "");
            setEditForm({
                school: userToDisplay.school || "",
                grade: userToDisplay.grade || "",
                favorite_genres: userToDisplay.favorite_genres || []
            });

            // Fetch this user's reviews
            console.log("Fetching reviews for user:", userToDisplay.id);
            const userReviews = await Review.filter({ creator_id: userToDisplay.id }, "-created_date");
            console.log("Found reviews:", userReviews.length);
            setReviews(userReviews);

            // Check follow status if a user is logged in and viewing another profile
            if(loggedInUser && loggedInUser.id !== userToDisplay.id) {
                const followCheck = await Follow.filter({ follower_id: loggedInUser.id, following_id: userToDisplay.id });
                setIsFollowing(followCheck.length > 0);
            } else if (loggedInUser && loggedInUser.id === userToDisplay.id) {
                setIsFollowing(false);
            }
        } else {
            console.error("No users found with ID:", targetId);
            setError("User not found.");
        }
    } catch (error) {
        console.error(`Failed to load profile for user ID: ${targetId}`, error);
        setError("Failed to load profile.");
    }

    setLoading(false);
  };

  const handleFollow = async () => {
    if (!currentUser || !profileUser || followLoading) return;
    setFollowLoading(true);
    try {
      await Follow.create({
        follower_id: currentUser.id,
        follower_name: currentUser.full_name,
        follower_school: currentUser.school,
        following_id: profileUser.id,
        following_name: profileUser.full_name,
        following_school: profileUser.school,
      });
      setIsFollowing(true);
    } catch (error) {
      console.error("Error following user:", error);
    }
    setFollowLoading(false);
  };
  
  const handleUnfollow = async () => {
    if (!currentUser || !profileUser || followLoading) return;
    setFollowLoading(true);
    try {
      const follows = await Follow.filter({
        follower_id: currentUser.id,
        following_id: profileUser.id,
      });
      for (const follow of follows) {
        await Follow.delete(follow.id);
      }
      setIsFollowing(false);
    } catch (error) {
      console.error("Error unfollowing user:", error);
    }
    setFollowLoading(false);
  };

  const handleSaveBio = async () => {
    if (!currentUser || !isOwnProfile) return;
    try {
      await User.updateMyUserData({ bio: newBio });
      setProfileUser(prev => ({ ...prev, bio: newBio }));
      setEditingBio(false);
    } catch (error) {
      console.error("Error saving bio:", error);
    }
  };

  const handleSaveProfile = async () => {
    if (!currentUser || !isOwnProfile) return;
    try {
      await User.updateMyUserData(editForm);
      setProfileUser(prev => ({ ...prev, ...editForm }));
      setEditingProfile(false);
    } catch (error) {
      console.error("Error saving profile:", error);
    }
  };

  const toggleGenre = (genre) => {
    setEditForm(prev => ({
      ...prev,
      favorite_genres: prev.favorite_genres?.includes(genre) 
        ? prev.favorite_genres.filter(g => g !== genre)
        : [...(prev.favorite_genres || []), genre]
    }));
  };

  const handlePhotoUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedPhoto(file);
      setShowPhotoEditor(true);
    }
  };

  const handleSavePhoto = async (croppedImage) => {
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file: croppedImage });
      await User.updateMyUserData({ profile_picture: file_url });
      setProfileUser(prev => ({ ...prev, profile_picture: file_url }));
      setShowPhotoEditor(false);
      setSelectedPhoto(null);
    } catch (error) {
      console.error("Error uploading photo:", error);
    } finally {
      setUploading(false);
    }
  };

  const isOwnProfile = currentUser && profileUser && currentUser.id === profileUser.id;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !profileUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <UserIcon className="h-16 w-16 text-slate-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-slate-800 mb-4">Profile Not Found</h1>
          <p className="text-slate-600 mb-6">
            {error || "This user's profile could not be loaded."}
          </p>
          <div className="space-y-2 text-sm text-slate-500">
            <p>Debug info:</p>
            <p>Profile ID: {profileId || "none"}</p>
            <p>Current User: {currentUser ? currentUser.full_name : "not logged in"}</p>
          </div>
          <RouterLink to={createPageUrl("Reviews")}>
            <Button variant="outline" className="mt-4">Back to Reviews</Button>
          </RouterLink>
        </div>
      </div>
    );
  }

  const renderActionButtons = () => {
    if (isOwnProfile) {
      return (
        <div className="absolute top-6 right-6 flex items-center gap-3">
          <Button onClick={() => setEditingProfile(true)} variant="outline">
            <Edit className="mr-2 h-4 w-4" /> Edit Profile
          </Button>
        </div>
      );
    }
    
    if (!currentUser) {
      return (
        <div className="absolute top-6 right-6">
          <Button onClick={() => User.login()}>
            <UserPlus className="mr-2 h-4 w-4" /> Sign In to Follow
          </Button>
        </div>
      );
    }
    
    return (
      <div className="absolute top-6 right-6 flex items-center gap-3">
        {isFollowing ? (
          <Button disabled={followLoading} onClick={handleUnfollow} variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
            Following
          </Button>
        ) : (
          <Button onClick={() => setShowFollowRequest(true)} disabled={followLoading}>
            <UserPlus className="mr-2 h-4 w-4" /> Follow
          </Button>
        )}
        <Button>
          <MessageCircle className="mr-2 h-4 w-4" /> Message
        </Button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-8">
      {editingProfile && isOwnProfile && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-md"
          >
            <Card className="bg-white border-0 shadow-2xl">
              <CardHeader className="flex flex-row items-center justify-between border-b">
                <h3 className="text-xl font-semibold">Edit Profile</h3>
                <Button variant="ghost" size="icon" onClick={() => setEditingProfile(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div>
                  <Label>School</Label>
                  <Input
                    value={editForm.school}
                    onChange={(e) => setEditForm(prev => ({...prev, school: e.target.value}))}
                  />
                </div>
                <div>
                  <Label>Grade</Label>
                  <Select value={editForm.grade} onValueChange={(value) => setEditForm(prev => ({...prev, grade: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {GRADES.map(grade => (
                        <SelectItem key={grade} value={grade}>
                          {grade.charAt(0).toUpperCase() + grade.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Favorite Genres</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {GENRES.map(genre => (
                      <Badge
                        key={genre}
                        onClick={() => toggleGenre(genre)}
                        variant={editForm.favorite_genres?.includes(genre) ? "default" : "outline"}
                        className="cursor-pointer"
                      >
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setEditingProfile(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button onClick={handleSaveProfile} className="flex-1">
                    <Save className="mr-2 h-4 w-4" /> Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}

      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl overflow-hidden mb-8 max-w-4xl mx-auto">
        <div className="relative p-8">
          {renderActionButtons()}
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="relative">
              <Avatar className="h-28 w-28 md:h-36 md:w-36 border-4 border-white shadow-lg">
                <AvatarImage src={profileUser.profile_picture} alt={profileUser.full_name} />
                <AvatarFallback className="text-4xl bg-blue-100 text-blue-600">
                  {profileUser.full_name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
              {isOwnProfile && (
                <div className="absolute bottom-0 right-0">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                    id="photo-upload"
                  />
                  <label htmlFor="photo-upload">
                    <Button size="icon" className="rounded-full bg-blue-600 hover:bg-blue-700">
                      <Camera className="h-4 w-4" />
                    </Button>
                  </label>
                </div>
              )}
            </div>

            <div className="text-center md:text-left">
              <h1 className="font-serif text-4xl font-bold text-slate-800">{profileUser.full_name || "Anonymous User"}</h1>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-2 text-slate-600">
                <div className="flex items-center gap-2">
                  <School className="h-4 w-4" />
                  <span>{profileUser.school || "School not specified"}</span>
                </div>
                {profileUser.grade && (
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-4 w-4" />
                    <span className="capitalize">{profileUser.grade}</span>
                  </div>
                )}
              </div>

              <div className="mt-4">
                {editingBio && isOwnProfile ? (
                  <div className="space-y-2">
                    <Textarea value={newBio} onChange={(e) => setNewBio(e.target.value)} maxLength={150} />
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => setEditingBio(false)}><X className="h-4 w-4"/></Button>
                      <Button variant="ghost" size="icon" onClick={handleSaveBio}><Check className="h-4 w-4"/></Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-3">
                    <p className="text-slate-700 italic">{profileUser.bio || "No bio yet."}</p>
                    {isOwnProfile && (
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditingBio(true)}>
                        <Edit className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          {profileUser.favorite_genres && profileUser.favorite_genres.length > 0 && (
            <div className="mt-6 flex flex-wrap justify-center md:justify-start gap-2">
              {profileUser.favorite_genres.map(genre => (
                <Badge key={genre} variant="secondary" className="bg-purple-100 text-purple-700">{genre}</Badge>
              ))}
            </div>
          )}
        </div>
      </Card>

      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-slate-700 mb-6 flex items-center gap-3">
          <BookOpen className="h-6 w-6 text-blue-600"/>
          {isOwnProfile ? "My Reviews" : `${profileUser.full_name?.split(' ')[0] || "User"}'s Reviews`}
        </h2>
        {reviews.length > 0 ? (
          <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {reviews.map(review => <ReviewCard key={review.id} review={review} />)}
          </div>
        ) : (
          <p className="text-center text-slate-500 py-12">No reviews posted yet.</p>
        )}
      </div>
      
      {showFollowRequest && (
        <SendFollowRequest
          targetUser={profileUser}
          onClose={() => setShowFollowRequest(false)}
          onRequestSent={() => {
            setShowFollowRequest(false);
          }}
        />
      )}

      {showPhotoEditor && selectedPhoto && (
        <ProfilePictureEditor
          imageFile={selectedPhoto}
          onSave={handleSavePhoto}
          onCancel={() => {
            setShowPhotoEditor(false);
            setSelectedPhoto(null);
          }}
          uploading={uploading}
        />
      )}
    </div>
  );
}
