import React from "react";
export default function FeedPage() {
    return <div>Feed Page - Coming Soon!</div>;
}