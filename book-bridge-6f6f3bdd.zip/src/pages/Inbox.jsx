import React from "react";
export default function InboxPage() {
    return <div>Inbox Page - Coming Soon!</div>;
}